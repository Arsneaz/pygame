import pygame
from sys import exit
from player import Player
from laser import Laser

# Default res for replit size if 800 * 600, we try to set to 600 * 600 and minimmize the screen to 90%


class Game:

    def __init__(self):
        # Player
        player_sprite = Player((screen_width / 2, screen_height), 5,
                               screen_width)
        self.player = pygame.sprite.GroupSingle(player_sprite)

        # health and score setup
        self.lives = 3
        self.live_surf = pygame.image.load(
            '../graphics/player.png').convert_alpha()
        self.live_x_start_pos = screen_width - (
            self.live_surf.get_size()[0] * 2 + 20)
        self.score = 0
        self.font = pygame.font.Font('../font/Pixeled.ttf', 20)

    def display_lives(self):
        for live in range(self.lives - 1):
            x = self.live_x_start_pos + (live *
                                         (self.live_surf.get_size()[0] + 10))
            screen.blit(self.live_surf, (x, 8))

    def display_score(self):
        score_surf = self.font.render(f'score: {self.score}', False, 'white')
        score_rect = score_surf.get_rect(topleft=(10, -10))
        screen.blit(score_surf, score_rect)


    def run(self):
        # Player
        self.player.update()
        self.player.draw(screen)
        # pygame.sprite.Group.draw
        # blit the Sprite images
        self.player.sprite.lasers.draw(screen)

        self.display_lives()
        self.display_score()


if __name__ == "__main__":
    pygame.init()
    screen_width = 600
    screen_height = 800
    screen = pygame.display.set_mode((screen_width, screen_height))
    game = Game()
    clock = pygame.time.Clock()

    ALIENSHOT = pygame.USEREVENT + 1
    pygame.time.set_timer(ALIENSHOT, 200)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.QUIT()
                exit()
            # if event.type == ALIENSHOT:
            #     game.alien_shoot()

        screen.fill((30, 30, 30))
        game.run()

        pygame.display.flip()
        clock.tick(60)
