import pygame
from laser import Laser


class Player(pygame.sprite.Sprite):
  # Define the pos of the player, mov. speed and the limit so the player didn't move to the other side

  # The base class for visible game objects. Derived classes will want to override the Sprite.update() and assign a
  # Sprite.image and Sprite.rect attributes. The initializer can accept any number of Group instances to be added to.
  # When subclassing the Sprite, be sure to call the base initializer before adding the Sprite to Groups. For example:

  def __init__(self, pos, speed, constraint):
    super().__init__()
    self.image = pygame.image.load('../graphics/player.png').convert_alpha()
    self.rect = self.image.get_rect(midbottom=pos)
    self.speed = speed
    self.constraint = constraint

    self.ready = True
    self.shoot_time = 0
    self.recharge_time = 600

    # We can create a laser by setting laser as group of sprite
    self.lasers = pygame.sprite.Group()

  def get_input(self):
    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
      self.rect.x -= self.speed
    if keys[pygame.K_RIGHT]:
      self.rect.x += self.speed

    if keys[pygame.K_SPACE] and self.ready:
      self.shoot_laser()
      self.ready = False
      # Getting the time interval between shoots
      self.shoot_time = pygame.time.get_ticks()

  def recharge(self):
    if not self.ready:
      # We make a timer interval between time after shot and compare it with the recharge time
      current_time = pygame.time.get_ticks()
      if current_time - self.shoot_time >= self.recharge_time:
        self.ready = True

  def set_constraint(self):
    if self.rect.left <= 0:
      self.rect.left = 0
    if self.rect.right >= self.constraint:
      self.rect.right = self.constraint

  def shoot_laser(self):
    self.lasers.add(Laser(self.rect.center, -8, self.rect.bottom))

  def update(self):
    self.get_input()
    self.set_constraint()
    self.recharge()
    self.lasers.update()
